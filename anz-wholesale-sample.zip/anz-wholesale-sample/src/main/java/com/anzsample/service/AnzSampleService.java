package com.anzsample.service;


import org.springframework.stereotype.Component;

import com.anzsample.exception.AccountNotFoundException;
import com.anzsample.response.AccountTransactionResponse;
import com.anzsample.response.CustomerAccountResponse;

@Component
public class AnzSampleService {

	public CustomerAccountResponse getCustAccounts(String customerID) {
		CustomerAccountResponse resp = new CustomerAccountResponse();
		if(!resp.getAccounts().get(0).getCustomerNum().equalsIgnoreCase(customerID)) {
			throw  new AccountNotFoundException("Account with this customer not found."+ customerID);
		}
		return resp;
	}
	
	public AccountTransactionResponse getAcctTransaction(String accountNum) {
		AccountTransactionResponse res= new AccountTransactionResponse();
		if(!res.getTransactionList().get(0).getAccountNum().equalsIgnoreCase(accountNum)) {
			throw new AccountNotFoundException(accountNum);
		}
		return res;
	}
	
}
