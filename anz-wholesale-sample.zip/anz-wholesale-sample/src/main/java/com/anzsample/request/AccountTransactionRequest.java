package com.anzsample.request;

import org.springframework.data.rest.core.annotation.RestResource;

@RestResource
public class AccountTransactionRequest {
public String accountNum;

public String getAccountNum() {
	return accountNum;
}

public void setAccountNum(String accountNum) {
	this.accountNum = accountNum;
}
}
