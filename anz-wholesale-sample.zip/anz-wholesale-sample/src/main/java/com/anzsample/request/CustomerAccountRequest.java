package com.anzsample.request;

import org.springframework.data.rest.core.annotation.RestResource;

@RestResource
public class CustomerAccountRequest {
public String CustomerNum;

public String getCustomerNum() {
	return CustomerNum;
}

public void setCustomerNum(String customerNum) {
	CustomerNum = customerNum;
}
}
