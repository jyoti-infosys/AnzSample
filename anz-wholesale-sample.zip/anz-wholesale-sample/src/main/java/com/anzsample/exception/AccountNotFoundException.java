package com.anzsample.exception;

public class AccountNotFoundException extends RuntimeException{
	
	private static final long serialVersionUID = 7293198968146412462L;

	public AccountNotFoundException(String id) {
		    super("Could not find account " + id);
		  }

}
