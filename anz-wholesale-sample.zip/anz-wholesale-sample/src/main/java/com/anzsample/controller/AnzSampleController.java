package com.anzsample.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.anzsample.exception.AccountNotFoundException;
import com.anzsample.response.AccountTransactionResponse;
import com.anzsample.response.CustomerAccountResponse;
import com.anzsample.service.AnzSampleService;

@RestController
@RequestMapping("/anz/v1")
public class AnzSampleController {
	@Autowired
	private AnzSampleService service;
	
	
	
	@GetMapping(value="/{customerID}")
	public @ResponseBody CustomerAccountResponse getCustomerAccounts(@PathVariable String customerID) throws AccountNotFoundException {
			
		return service.getCustAccounts(customerID);
	}
	
	@GetMapping(value="/{accountNum}/transaction")
	public @ResponseBody AccountTransactionResponse getAccountTransactions(@PathVariable String accountNum) throws AccountNotFoundException {
		return service.getAcctTransaction(accountNum);
	}
}
