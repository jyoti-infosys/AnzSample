package com.anzsample.beans;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;

import org.springframework.stereotype.Component;

@Component
public class Transactions {
	public String accountNum;
	public String accountName;
	public String Currency;
	public LocalDate transactionDate;
	public Double debitAmount;
	public Double creditAmount;
	public String transactionType;
	public String transactionNarr;
	
	
	public String getAccountNum() {
		return accountNum;
	}
	public void setAccountNum(String accountNum) {
		this.accountNum = accountNum;
	}
	public String getAccountName() {
		return accountName;
	}
	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}
	public String getCurrency() {
		return Currency;
	}
	public void setCurrency(String currency) {
		Currency = currency;
	}
	public String getTransactionDate() {
		String txnDate =  DateTimeFormatter.ofLocalizedDate(FormatStyle.MEDIUM)
				  .format(transactionDate);
		return txnDate;
	}
	public void setTransactionDate(LocalDate transactionDate) {
		this.transactionDate = transactionDate;
	}
	public Double getDebitAmount() {
		return debitAmount;
	}
	public void setDebitAmount(Double debitAmount) {
		this.debitAmount = debitAmount;
	}
	public Double getCreditAmount() {
		return creditAmount;
	}
	public void setCreditAmount(Double creditAmount) {
		this.creditAmount = creditAmount;
	}
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	public String getTransactionNarr() {
		return transactionNarr;
	}
	public void setTransactionNarr(String transactionNarr) {
		this.transactionNarr = transactionNarr;
	}
	

}
