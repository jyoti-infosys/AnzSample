package com.anzsample.response;

import java.time.LocalDate;
import java.util.ArrayList;

import org.springframework.stereotype.Component;

import com.anzsample.beans.Transactions;

@Component
public class AccountTransactionResponse {
	
	public  AccountTransactionResponse() {
		transactionList= this.getstubbedTransactions();
	}
	
public ArrayList<Transactions> transactionList;

public ArrayList<Transactions> getTransactionList() {
	return transactionList;
}

public void setTransactionList(ArrayList<Transactions> transactionList) {
	this.transactionList = transactionList;
}


private ArrayList<Transactions> getstubbedTransactions() {
	//AccountTransactionResponse res= new AccountTransactionResponse();
	ArrayList<Transactions> txns = new ArrayList<Transactions>();
	Transactions txn= new Transactions();
	txn.setAccountName("Test");
	txn.setAccountNum("12348");
	txn.setCreditAmount(1000.00);
	txn.setCurrency("USD");
	txn.setTransactionDate(LocalDate.of(2020, 01, 01));
	txn.setTransactionNarr("salary cr");
	txn.setTransactionType("CR");
	txns.add(txn);
	
	txn=new Transactions();
	txn.setAccountName("Test");
	txn.setAccountNum("12348");
	txn.setCreditAmount(20.00);
	txn.setCurrency("USD");
	txn.setTransactionDate(LocalDate.of(2020, 01, 02));
	txn.setTransactionNarr("");
	txn.setTransactionType("DR");
	txns.add(txn);
	
	txn=new Transactions();
	txn.setAccountName("Test");
	txn.setAccountNum("12348");
	txn.setCreditAmount(200.00);
	txn.setCurrency("USD");
	txn.setTransactionDate(LocalDate.of(2020, 01, 04));
	txn.setTransactionNarr("Online purchase");
	txn.setTransactionType("CR");
	txns.add(txn);
	
	new Transactions();
	txn.setAccountName("Test");
	txn.setAccountNum("12348");
	txn.setCreditAmount(30.00);
	txn.setCurrency("USD");
	txn.setTransactionDate(LocalDate.of(2020, 01, 07));
	txn.setTransactionNarr("POS");
	txn.setTransactionType("DR");
	txns.add(txn);
	
	new Transactions();
	txn.setAccountName("Test");
	txn.setAccountNum("12348");
	txn.setCreditAmount(5.00);
	txn.setCurrency("USD");
	txn.setTransactionDate(LocalDate.of(2020, 01, 07));
	txn.setTransactionNarr("POS");
	txn.setTransactionType("DR");
	txns.add(txn);
	
	txn=new Transactions();
	txn.setAccountName("Test");
	txn.setAccountNum("12348");
	txn.setCreditAmount(56.00);
	txn.setCurrency("USD");
	txn.setTransactionDate(LocalDate.of(2020, 01, 9));
	txn.setTransactionNarr("Coffee");
	txn.setTransactionType("DR");
	txns.add(txn);
	
	//res.setTransactionList(txns);
	
	return txns;
}

}
