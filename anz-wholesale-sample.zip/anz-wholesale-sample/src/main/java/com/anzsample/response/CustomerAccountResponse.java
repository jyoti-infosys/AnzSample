package com.anzsample.response;

import java.time.LocalDate;
import java.util.ArrayList;

import org.springframework.stereotype.Component;

import com.anzsample.beans.Accounts;

@Component
public class CustomerAccountResponse {
	public ArrayList<Accounts> accounts;
	//private CustomerAccountResponse res;
	
	public  CustomerAccountResponse() {
		accounts=  this.getStubbedAccounts();
	}

	public ArrayList<Accounts> getAccounts() {
		return accounts;
	}

	public void setAccounts(ArrayList<Accounts> accounts) {
		this.accounts = accounts;
	}
	
	public ArrayList<Accounts> getStubbedAccounts() {
	//	CustomerAccountResponse res = new CustomerAccountResponse();
		ArrayList<Accounts> accounts = new ArrayList<Accounts>();
		Accounts acct = new Accounts();
		acct.setAccountBalance(1000.0);
		acct.setAccountName("Test");
		acct.setAccountNum("12345");
		acct.setAccountType("Saving");
		acct.setBalanceDate(LocalDate.of(2020, 4, 23));
		acct.setCurrency("USD");
		acct.setCustomerNum("Cust1234");
		
		accounts.add(acct);
		acct = new Accounts();
		acct.setAccountBalance(1008.0);
		acct.setAccountName("Test");
		acct.setAccountNum("12346");
		acct.setAccountType("current");
		acct.setBalanceDate(LocalDate.of(2020, 3, 13));
		acct.setCurrency("USD");
		acct.setCustomerNum("Cust1234");
		accounts.add(acct);
		
		acct = new Accounts();
		acct.setAccountBalance(80.0);
		acct.setAccountName("Test");
		acct.setAccountNum("12348");
		acct.setAccountType("saving");
		acct.setBalanceDate(LocalDate.of(2019, 12, 20));
		acct.setCurrency("USD");
		acct.setCustomerNum("Cust1234");
		accounts.add(acct);
		
		//res.setAccounts(accounts);
		return accounts;
	}
}
