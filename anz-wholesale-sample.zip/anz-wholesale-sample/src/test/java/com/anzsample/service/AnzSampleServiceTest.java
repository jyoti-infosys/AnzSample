package com.anzsample.service;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;

import com.anzsample.exception.AccountNotFoundException;


@RunWith(JUnit4.class)
public class AnzSampleServiceTest {
		 
	   
	    private AnzSampleService anzSampleService;
	    
	    @Rule
	    public ExpectedException exception = ExpectedException.none();
	
	@Before
	public void setUp() {
		anzSampleService= new AnzSampleService();
	}	
	
	@Test
	public void whenCusttNum_returnAccts() {
		assertEquals("Test", anzSampleService.getCustAccounts("Cust1234").getAccounts().get(0).getAccountName());
	}
	
	@Test
	public void whenAcctNum_returnTxn() {
		assertEquals("USD", anzSampleService.getAcctTransaction("12348").getTransactionList().get(0).getCurrency());
	}
	
	@Test
	public void whenAcctNull_throwException() {
		 exception.expect(AccountNotFoundException.class);
		 exception.expectMessage("Could not find account");
		anzSampleService.getAcctTransaction(null);
	}
	
	@Test
	public void whenCustNotMatch_throwException() {
		 exception.expect(AccountNotFoundException.class);
		 exception.expectMessage("customer not found");
		anzSampleService.getCustAccounts("233");
	}
	
	
	
}
