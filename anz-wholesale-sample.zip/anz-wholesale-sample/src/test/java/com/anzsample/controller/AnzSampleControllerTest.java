package com.anzsample.controller;

import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
public class AnzSampleControllerTest {
	
	/*@Test
	public void giventUrl_whenGetRequest_thenFindGetResponse() 
	  throws Exception {
	 
	    MockHttpServletRequestBuilder builder = MockMvcRequestBuilders
	      .get("/get");
	 
	    ResultMatcher contentMatcher = MockMvcResultMatchers.content()
	      .string("GET Response");
	 
	    this.mockMvc.perform(builder).andExpect(contentMatcher)
	      .andExpect(MockMvcResultMatchers.status().isOk());
	 
	}
*/
}
